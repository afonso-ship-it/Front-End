<template>
  <div id="app">
    <div>
      <b-navbar type="dark" variant="dark">
        <b-navbar-nav>
          <b-nav-item href="/">Home</b-nav-item>
          <b-nav-item href="/About">About</b-nav-item>
          <b-nav-item href="/Profile">Profile</b-nav-item>
          <b-nav-item href="/Profiles">Profiles</b-nav-item>

          <!-- Navbar dropdowns -->
          <b-nav-item-dropdown text="Lang" right>
            <b-dropdown-item href="#">EN</b-dropdown-item>
            <b-dropdown-item href="#">ES</b-dropdown-item>
            <b-dropdown-item href="#">RU</b-dropdown-item>
            <b-dropdown-item href="#">FA</b-dropdown-item>
          </b-nav-item-dropdown>

          <b-nav-item-dropdown text="User" right>
            <b-dropdown-item href="/Home">Account</b-dropdown-item>
            <b-dropdown-item href="#">Settings</b-dropdown-item>
          </b-nav-item-dropdown>

          <b-button v-b-toggle.sidebar-1>Toggle Sidebar</b-button>
          <b-sidebar id="sidebar-1" title="Projeto" shadow>
            <div class="px-3 py-2">
              <p>
                Nome: João Afonso Sardinha Reis <br />Nº: 2046520
                <br />Disciplina: Front-End
              </p>
              <b-img
                src="https://blog.hubbado.com/content/images/2020/01/projectmanager.png"
                fluid
                thumbnail
              ></b-img>
            </div>
          </b-sidebar>
        </b-navbar-nav>
      </b-navbar>
    </div>
    <!--<div id="nav">
      <router-link to="/">Home</router-link> |
      <router-link to="/about">About</router-link>
      <router-link to="Profile/">Profile</router-link> |
    </div> -->
    <router-view />
  </div>
</template>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  /* width: 100%;
  margin: 0px auto 0px auto; */
}

#nav {
  padding: 30px;
}

#nav a {
  font-weight: bold;
  color: #2c3e50;
}

#nav a.router-link-exact-active {
  color: #42b983;
}
</style>
