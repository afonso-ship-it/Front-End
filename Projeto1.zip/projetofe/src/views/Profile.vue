<template>
  <div class="Profile">
  </div>
</template>

<script>
// @ is an alias to /src
//import HelloWorld from '@/components/HelloWorld.vue'

export default {
  name: "Profile",
  components: {
    //HelloWorld
  },
};
</script>
