<template>
    <h1>This is the profile page for {{$route.params.id}}</h1>
</template>