<template>
    <v-container>
        <v-row>
            <h1 style="padding-top:75px">
                Produto
            </h1>
        </v-row>
        <div>
            {{info.name}}
        </div>
    </v-container>
</template>

<script>
import axios from "axios";
export default{
    props : ['id'],
    data () {
    return {
      info: null
        }
    },
    mounted () {
        axios
        .get('https://www.vagalume.com.br/u2/index.js')
        .then(response => (this.info = response.data))
        console.log(this.info);
    }
}
</script>